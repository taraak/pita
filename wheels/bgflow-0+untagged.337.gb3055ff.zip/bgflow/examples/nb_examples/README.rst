Example Notebooks
==================

Below is a gallery of example jupyter notebooks
They are only rendered if they are named example_{name}.ipynb