Boltzmann Generators
====================


.. currentmodule:: bgflow
.. autosummary::
   :toctree: generated/
   :template: class.rst

    bg.BoltzmannGenerator


