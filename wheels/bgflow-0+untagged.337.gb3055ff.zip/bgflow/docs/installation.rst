Installation
============

To come via pip

.. code-block:: console

    pip install bgtorch

or conda-forge

.. code-block:: console

    conda install -c conda-forge bgtorch