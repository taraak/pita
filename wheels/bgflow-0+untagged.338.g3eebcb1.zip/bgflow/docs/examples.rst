Examples
=========

.. toctree::
   :maxdepth: 1

   examples/index.rst
   nb_examples/index.rst
   datasets/index.rst
