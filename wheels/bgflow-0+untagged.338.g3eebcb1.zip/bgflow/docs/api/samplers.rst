Sampling
========


.. automodule:: bgflow.distribution

.. toctree::
   :maxdepth: 1
