from ._init_gaussian_impl import from_data
