from torchdyn.numerics.solvers.templates import DiffEqSolver, MultipleShootingDiffeqSolver

class EulerMaruyama(DiffEqSolver):
    def __init__(self):
        raise NotImplementedError