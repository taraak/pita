from .naive_intNwo import intN_weight_only

__all__ = [
    "intN_weight_only",
]
