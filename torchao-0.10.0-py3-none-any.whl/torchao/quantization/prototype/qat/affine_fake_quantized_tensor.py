from torchao.quantization.qat.affine_fake_quantized_tensor import (
    AffineFakeQuantizedTensor,
    to_affine_fake_quantized,
)

__all__ = [
    "AffineFakeQuantizedTensor",
    "to_affine_fake_quantized",
]
