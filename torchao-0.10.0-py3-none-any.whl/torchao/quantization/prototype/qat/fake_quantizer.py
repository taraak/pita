from torchao.quantization.qat.fake_quantizer import (
    FakeQuantizer,
)

__all__ = [
    "FakeQuantizer",
]
